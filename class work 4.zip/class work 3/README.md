# CSS 217 — Beyond Design Patterns: Java Optimization Lab

Runnable demos for every point of the handout (Sufyan bin Uzayr).

| File | Handout section |
|---|---|
| `Trap1Autoboxing.java` | Trap 1 — `Integer` vs `int` / `ToIntFunction<T>` |
| `Trap2CollectionGrowth.java` | Trap 2 — `new ArrayList<>()` vs `new ArrayList<>(expectedSize)` |
| `Trap3StringConcat.java` | Trap 3 — `+=` in a loop vs `StringBuilder` |
| `Trap4StreamsHotLoop.java` | Trap 4 — Streams vs counted `for` in a hot loop |
| `PatternCost.java` | Section 1 — megamorphic Strategy, Decorator pointer chasing, Adapter GC churn |
| `ChecklistRefactor.java` | Section 6 — "Before You Abstract" checklist applied to code |
| `Bench.java` | tiny harness (warm-up, best-of-7, blackhole) |

## Run
```bash
javac -d out src/lab/*.java
java -cp out lab.Main            # everything
java -cp out lab.Main 3 p        # only Trap 3 + pattern costs
java -Xlog:gc -cp out lab.Main p # watch Young GC pauses (Section 1C)
```

## Sample results (JDK 21, Linux)
| Demo | Bad | Good | Speed-up |
|---|---|---|---|
| Trap 1 autoboxing | 10.5 ms | 3.6 ms | ×2.9 |
| Trap 2 ArrayList sizing | 30.3 ms | 15.7 ms | ×1.9 (31 resizes avoided) |
| Trap 3 string concat (20k) | 236.6 ms | 0.4 ms | ×560 (O(n²) vs O(n)) |
| Trap 4 streams in hot loop | 12.5 ms | 10.4 ms | ×1.2 |
| Strategy mega- vs monomorphic | 55.8 ms | 14.2 ms | ×3.9 |
| 8 decorators vs plain object | 68.7 ms | 11.5 ms | ×6.0 |
| Adapter per call vs reused | 71.4 ms | 34.6 ms | ×2.1 |

Your numbers will differ — that is the point of Section 5: **measure, don't guess**.
For serious measurements use JMH; this harness is a classroom demo.
