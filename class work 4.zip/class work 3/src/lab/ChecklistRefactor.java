package lab;

import java.util.List;
import java.util.function.Predicate;
public final class ChecklistRefactor {

    // [BAD] OVER-ENGINEERED: interface + one implementation + factory, for a fixed rule.
    interface PassPolicy { boolean passes(int score); }
    static final class MinistryPassPolicy implements PassPolicy {
        public boolean passes(int score) { return score >= 50; }
    }
    static final class PassPolicyFactory {
        static PassPolicy create() { return new MinistryPassPolicy(); }
    }
    static final int PASS_THRESHOLD = 50;
    static boolean passes(int score) { return score >= PASS_THRESHOLD; }

    // [GOOD] When filtering really is configurable, the standard library already has the abstraction:
    static long countMatching(List<Integer> scores, Predicate<Integer> rule) {
        return scores.stream().filter(rule).count();
    }

    public static void run() {
        Bench.header("Section 6 - 'Before You Abstract' checklist");
        String[][] answers = {
            {"More than one implementation right now?",          "No - only MinistryPassPolicy"},
            {"Changes dynamically at runtime?",                  "No - fixed rule, known at compile time"},
            {"Does Function/Predicate/Supplier already fit?",    "Yes - Predicate<Integer> if it ever must be configurable"},
            {"Would it obscure a 3:00 AM stack trace?",          "Yes - factory + interface + impl = 3 hops to the real logic"},
            {"Real requirement today or imaginary one?",         "Imaginary - 'maybe we will have other policies'"},
        };
        for (String[] a : answers) System.out.printf("   [ ] %-48s -> %s%n", a[0], a[1]);
        System.out.println("   Verdict: delete PassPolicy/Factory, keep a static method.");

        PassPolicy p = PassPolicyFactory.create();
        List<Integer> scores = List.of(30, 55, 72, 49, 100, 50);
        long a = scores.stream().filter(p::passes).count();
        long b = scores.stream().filter(ChecklistRefactor::passes).count();
        long c = countMatching(scores, s -> s >= PASS_THRESHOLD);
        System.out.println("   Same result from all three versions: " + a + " / " + b + " / " + c + " passed");
    }
}
