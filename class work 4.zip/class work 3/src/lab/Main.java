package lab;

public final class Main {
    public static void main(String[] args) {
        String sel = args.length == 0 ? "1234pc" : String.join("", args);
        System.out.println("Java " + System.getProperty("java.version") + " - times are best-of-7 after warm-up");
        if (sel.contains("1")) Trap1Autoboxing.run();
        if (sel.contains("2")) Trap2CollectionGrowth.run();
        if (sel.contains("3")) Trap3StringConcat.run();
        if (sel.contains("4")) Trap4StreamsHotLoop.run();
        if (sel.contains("p")) PatternCost.run();
        if (sel.contains("c")) ChecklistRefactor.run();
        System.out.println();
        System.out.println("Remember: these are micro-benchmarks. Profile real code (VisualVM / async-profiler) before optimizing.");
    }
}
