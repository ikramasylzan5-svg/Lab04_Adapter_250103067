package lab;

import java.util.ArrayList;
import java.util.List;

/** Trap 2: under-sized collection growth (ArrayList resizes ~1.5x and copies). */
public final class Trap2CollectionGrowth {

    public static void run() {
        Bench.header("Trap 2 - Under-sized collection growth");
        final int expectedSize = 2_000_000;
        String value = "record";

        Bench.compare("add " + expectedSize + " items",
                "new ArrayList<>()", () -> {
                    List<String> records = new ArrayList<>();
                    for (int i = 0; i < expectedSize; i++) records.add(value);
                    return records.size();
                },
                "new ArrayList<>(expectedSize)", () -> {
                    List<String> records = new ArrayList<>(expectedSize);
                    for (int i = 0; i < expectedSize; i++) records.add(value);
                    return records.size();
                });

        // Count how many times the default ArrayList had to grow (10 -> 15 -> 22 -> ...).
        int capacity = 10, resizes = 0;
        while (capacity < expectedSize) { capacity = capacity + (capacity >> 1); resizes++; }
        System.out.println("   default list resized " + resizes + " times (each = new array + System.arraycopy)");
    }
}
