package lab;

import java.util.Arrays;

/** Trap 4: Streams in hot loops vs classic counted for-loop. */
public final class Trap4StreamsHotLoop {

    public static void run() {
        Bench.header("Trap 4 - Streams in hot loops");
        final int[] data = new int[1_000];
        for (int i = 0; i < data.length; i++) data[i] = i;
        final int calls = 50_000;   // a "hot" method called many times on small arrays

        Bench.compare(calls + " calls: sum of even squares",
                "Arrays.stream().filter().map().sum()", () -> {
                    long total = 0;
                    for (int c = 0; c < calls; c++)
                        total += Arrays.stream(data).filter(x -> (x & 1) == 0).map(x -> x * x).sum();
                    return total;
                },
                "classic for loop", () -> {
                    long total = 0;
                    for (int c = 0; c < calls; c++) {
                        int s = 0;
                        for (int i = 0; i < data.length; i++) {
                            int x = data[i];
                            if ((x & 1) == 0) s += x * x;
                        }
                        total += s;
                    }
                    return total;
                });
        System.out.println("   Streams are still the right choice for readable business logic outside hot paths.");
    }
}
